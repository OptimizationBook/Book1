#include <iostream>
#include <time.h>
#include <math.h>
#include <chrono>
#include <stdlib.h>
using namespace std;


int main(){
    cout << "Enter size of array:\n";
    unsigned N;
    cin >> N;
    double a[N][N], c[N], b[N];
    for (unsigned i = 0; i < N; i++){
        c[i] = double(i);
        b[i] = double(i);
        for(unsigned j = 0; j < N; j++)
            a[i][j] = double(i * j) / double(N);
    }

    auto start = chrono::steady_clock::now();

    for (unsigned i = 0; i < N; i++)
        for (unsigned j = 0; j < N; j++)
            c[i] = c[i] + a[i][j] * b[j];

    auto end = chrono::steady_clock::now();
//    for (unsigned i = 0; i < N; i++)
//        c[i] = double(i);
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loop time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    for(unsigned i = 0; i < N; i += 2)
        for(unsigned j = 0; j < N; j+= 2)
            for(unsigned ii = i; ii < min(i + 2, N); ii++)
                for(unsigned jj = j; jj < min(j + 2, N); jj++){
                    c[ii] = c[ii] + a[ii][jj] * b[jj];
                }
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "tiled loop time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

