#include <iostream>
#include <chrono>
//испытание примеров 1,2,3,4 из раздела с массивами 
using namespace std;
int main(){
    unsigned N = 1000000;
    long unsigned array[N], i;
    auto start = chrono::steady_clock::now();
    for ( i = 0; i < N; i++)
        array[i] = N;
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << elapsed_ms.count()<< " mcs\n";
    start = chrono::steady_clock::now();
    long unsigned* arrn = array + N;
    for(long unsigned* ptr_int = array; ptr_int < arrn; ptr_int++)
        *ptr_int = N;
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << elapsed_ms.count()<< " mcs\n\n";
    N = 300;

    int matr[N][N];
    start = chrono::steady_clock::now();
    for (unsigned i = 0; i < N; i++)
        for(unsigned j = 0; j < N; j++){
            matr[i][j] = 1;
        }
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << elapsed_ms.count()<< " mcs\n\n";
    int* p = &matr[0][0];
    int* matrn = &matr[0][0] + N * N;
    start = chrono::steady_clock::now();
    for (p = *matr; p < matrn; p++)
        *p = 1;
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << elapsed_ms.count()<< " mcs\n";
/*
    long unsigned sum = 0;
    start = chrono::steady_clock::now();
    for(size_t i = 0; i < N; i++)
        for(size_t j = 0; j < N; j++)
            sum += mattr[i][j];
    cout << sum << endl;
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << elapsed_ms.count()<< " mcs\n";
    sum = 0;
    long unsigned *p = &mattr[0][0];
    float size = sizeof(mattr)/ sizeof(long unsigned);
    start = chrono::steady_clock::now();
    for(size_t i = 0; i < size; i++){
        sum += *p;
        p++;
    }
    cout << sum<< endl;
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << elapsed_ms.count()<< " mcs\n\n";
*/    return 0;
}
