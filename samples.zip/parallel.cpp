#include <iostream>
#include <ctime>
#include <chrono>
using namespace std;

void loop(double* b, double* c, double* f, double* e,double* x,
       double* y, double* z, double* r, double* d, unsigned N){
    long unsigned size = N * N + N;
    double a[size];
    for (int j = 0; j < N; j++){
        for (int k = 0; k < N; k++){
            for (int m = 0; m < N; m++){
                unsigned i = j * k + m;
                a[i] = b[i] * c[i] + f[i]/e[i]+ x[i] - y[i] +
                z[i]/r[i] + d[i] * x[i];
            }
        }
    }
}

void paralleled_loop(double* b, double* c, double* f, double* e,double* x,
       double* y, double* z, double* r, double* d, unsigned N){
    long unsigned size = N * N + N;
    double a[size];
    for (int j = 0; j < N; j++){
        for (int k = 0; k < N; k++){
            double tmp;
            for (int m = 0; m < N; m++){
                unsigned i = j * k + m;
                tmp = b[i] * c[i] + f[i]/e[i];
                a[i] = tmp - y[i] + z[i]/r[i] + 
                (d[i] + 1) * x[i];
                }
        }
    }
}

int main(){
    unsigned N;
    cout << "Enter N - size of arrays:\n";
    cin >> N;
    double x[N], y[N], z[N], b[N], c[N], d[N], e[N], f[N], r[N];
    for (unsigned i = 0; i < N; i++){
        b[i] = (double)i;
        c[i] = (double)i + 1;
        d[i] = (double)i + 2;
        e[i] = (double)i + 3;
        f[i] = (double)i + 4;
        x[i] = (double)i + 5;
        y[i] = (double)i + 6;
        z[i] = (double)i + 7;
        r[i] = (double)i + 8;
    }
    auto start = chrono::steady_clock::now();
    loop(b, c, d, e, f, x, y, z, r, N);
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loop time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    paralleled_loop(b, c, d, e, f, x, y, z, r, N);
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "parallel loop time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

