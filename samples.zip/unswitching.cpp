#include <iostream>
#include <time.h>
#include <math.h>
#include <chrono>
using namespace std;

void loop1(int i,int w,int* x, int* y){
    for(i = 0; i < 100000; i++){
        x[i] += y[i];
        if (w)
            y[i] = 0;
    }
}


void loop2(int i,int w,int* x, int* y){
    if (w){
        for(i = 0; i < 100000; i++){
            x[i] += y[i];
            y[i] = 0;
        }
    }
        else{
            for(i = 0; i < 100000; i++)
                x[i] += y[i];
    }
}

int main(){
    int i, w, x[100000], y[100000];
    auto start = chrono::steady_clock::now();
    loop1(i, w, x, y);
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loop time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    loop2(i, w, x, y);
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "unswitched loop time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

