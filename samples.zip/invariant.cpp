#include <iostream>
#include <time.h>
#include <math.h>
#include <chrono>
using namespace std;

void loop1(double* a, unsigned N){
    double z = 5, y = 4, x;
    for (unsigned i = 0; i < N; i++){
        x = y + z;
        x *= 0.5;
        a[i] = 6 * double(i) + x * x;
    }
}


void loop2(double* a, unsigned N){
    double z = 5, y = 4, x;
    x = y + z;
    x*= 0.5;
    double t1 = x * x;
    for (unsigned i = 0; i < N; i++){
        a[i] = 6 * double(i) + t1;
    }
}

int main(){
    cout << "Enter size of array:\n";
    unsigned N;
    cin >> N;
    double a[N];
    for (unsigned i = 0; i < N; i++)
       a[i] = i / double(N); 
    auto start = chrono::steady_clock::now();
    loop1(a, N);
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loop time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    loop2(a, N);
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "invarianted loop time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

