#include <iostream>
#include <time.h>
#include <math.h>
#include <chrono>
using namespace std;

double loop1(double* a, unsigned N){
    double res = 1;
    for (unsigned i = 0; i < N - 1; i++){
        res *= cos(a[i] + a[i + 1]);
    }
    return res;
}


double loop2(double* a, unsigned N){
    double res = 1;
    for (unsigned i = 0; i < N - 1; i ++){
        res *= (cos(a[i]) * cos(a[i + 1]) - sin(a[i]) * sin(a[i + 1]));
    }
    return res;
}

int main(){
    cout << "Enter size of array:\n";
    unsigned N;
    cin >> N;
    double a[N];
    for (unsigned i = 0; i < N; i++)
       a[i] = i / double(N); 
    auto start = chrono::steady_clock::now();
    loop1(a, N);
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loop time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    loop2(a, N);
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "defactorized loop time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

