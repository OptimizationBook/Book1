#include <iostream>
#include <ctime>
#include <chrono>
using namespace std;

void loops(int ( *a )[100], int ( *b )[100], int ( *c )[100], unsigned N){
}

void replaced_loops(int** a, int** b, int** c, unsigned N){
}

int main(){
    unsigned N = 200;
    //cout << "Enter N - size of matrix:\n";
   // cin >> N;
    int c[N][N], a[N][N], b[N][N];
    for (unsigned i = 0; i < N; i++)
        for (unsigned j = 0; j < N; j++){
            a[i][j] = i;
            b[i][j] = j;
            c[i][j] = i+j;
        }
    //clock_t start = clock();
    auto start = chrono::steady_clock::now();
    
    for(int i = 0; i < N; i++)
        for(int j = 0; j < N; j++)
            for(int k = 0; k < N; k++)
                c[i][j] = c[i][j] + a[i][k] * b[k][j];
    //fusion_loops(a, b, d, e, N);
    //clock_t end = clock();
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loops time:" << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    
    for(int i = 0; i < N; i++)
        for(int k = 0; k < N; k++)
            for(int j = 0; j < N; j++)
                c[i][j] = c[i][j] + a[i][k] * b[k][j];
    //clock_t end = clock();
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "replaced loops time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

