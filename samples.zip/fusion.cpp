#include <iostream>
#include <ctime>
#include <chrono>
using namespace std;

void parted_loops(int* a, int* b, int* d, int* e, unsigned N){
    for(unsigned i = 0; i < N; i++)
        a[i] = b[i] - 5;
    for(unsigned i = 0; i < N - 1; i++)
        d[i] = e[i] * 3;
}

void fusion_loops(int* a, int* b, int* d, int* e, unsigned N){
    for(unsigned i = 0; i < N - 1; i++){
        a[i] = b[i] - 5;
        d[i] = e[i] * 3;
    }
    a[N - 1] = b[N - 1] - 5;
}

int main(){
    unsigned N;
    cout << "Enter N - size of arrays:\n";
    cin >> N;
    int a[N], b[N], d[N - 1], e[N - 1];
    for (unsigned i = 0; i < N; i++){
        b[i] = i + 5;
        e[i] = i;
    }
    //clock_t start = clock();
    auto start = chrono::steady_clock::now();
    parted_loops(a, b, d, e, N);
    //fusion_loops(a, b, d, e, N);
    //clock_t end = clock();
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "parted loops time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    fusion_loops(a, b, d, e, N);
    //clock_t end = clock();
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "fusion loops time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

