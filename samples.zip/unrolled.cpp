#include <iostream>
#include <time.h>
#include <chrono>
using namespace std;

long unsigned loop1(unsigned* a, unsigned N){
    long unsigned res = 1;
    for (unsigned i = 0; i < N; i++){
        res *= a[i];
    }
    return res;
}


long unsigned loop2(unsigned* a, unsigned N){
    long unsigned res = 1;
     long unsigned res1 = 1, res2 = 1, res3 = 1;
    for (unsigned i = 0; i < N; i += 3){
        res1 *= a[i];
        res2 *= a[i + 1];
        res3 *= a[i + 2];
    }
    res = res1 * res2 * res3;
    return res;
}

int main(){
    cout << "Enter size of array:\n";
    unsigned N;
    cin >> N;
    unsigned a[N];
    for (unsigned i = 0; i < N; i++)
       a[i] = i + 1; 
    auto start = chrono::steady_clock::now();
    loop1(a, N);
    auto end = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "loop time: " << elapsed_ms.count() << " microseconds" << endl;
    start = chrono::steady_clock::now();
    loop2(a, N);
    end = chrono::steady_clock::now();
    elapsed_ms = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "unrolled loop time: " << elapsed_ms.count() << " microseconds" << endl;
    return 0;
}

